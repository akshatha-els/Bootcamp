//3
console.log(0 / 5)
console.log(3 * 'a')
console.log('a' * 3)
//4
console.log(parseInt('Banana'));
console.log(parseInt('22.222'));
console.log(parseFloat(12));
console.log(parseFloat(13.3));
var num1 = 10; 
console.log(num1.toFixed(2));

var num1 = 15.456789; 
console.log(num1.toFixed())

var num1 = 15.456789; 
console.log(number.toFixed(2))

var num1 = 15.456789; 
console.log(num1.toFixed(3))
//5

var mStr = "This is my test string to practice the JavaScript string function concepts.This is gonna be fun."
console.log(mStr.slice(-12))
console.log(mStr.length)
// Returns the length of the string
console.log(myFirstString.length)
console.log(mStr.lastIndexOf('This'))
console.log(myFirstString.substr(0, 4))
console.log(mStr.substr(0, 12))
console.log(mStr.slice(12,-10))

//7
var str1 = 'Today is';
var str2 = ' A beautiful day'
var str3 = ' In Hawaii.'
var Result= console.log(str1 + ' ' + str2 + ' ' + str3)

var mStr = 'Mo Tu We Th Fr Sa Su'
console.log(mStr.toUpperCase())
console.log(mStr.split(','))

//8
var mNum;
console.log(mNum) //undefined
var mNum = null
console.log(mNum) //null

console.log(undefined == null) //true
console.log(undefined === null)//false

//9
var length=200;
var breadth=200;
if (length == length ) {
	console.log('true, its a square')
} else {
    console.log('false, not a square')
}

var num1=5, num2=8, num3=20;
if (num1 >= num2 && num1 >= num3) {
    return num1;
} else if (num2 >= num1 && num2 >= num3) {
    return num2;
} else {
    return num3;
}